## 1.0.1

- Added new mod icon by PlNK.

## 1.0.0

- First release